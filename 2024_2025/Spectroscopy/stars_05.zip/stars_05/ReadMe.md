We have 42 (5) template spectera, and 4 observed stars. The task is to use fxcor to check out the correlation between templates and observations, and finally, based on the highest HGHT value, 
derive the type of the observed star.

Tasks:
- [ ] Retrieve crossfiles with 5 solid templates
- [ ] Try to run 42 templates
- [ ] Generate the code, showing the height value (as a vertical histogram) for different templates for each of the observed stars
- [ ] Based on that, make the dict of {observed star : type}
